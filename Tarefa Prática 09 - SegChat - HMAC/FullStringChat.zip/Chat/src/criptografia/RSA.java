/*
 * Seguranca Computacional 2019.1 - Prof. Dr. Valerio Rosset
 * Pratica 09 
 * Nome: Flavia Yumi Ichikura RA: 111791
 * Nome: Willian Dihanster Gomes de Oliveira RA: 112269	
 */
package criptografia;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import static sun.security.x509.CertificateAlgorithmId.ALGORITHM;

/**
 *
 * @author Flávia Yumi
 */
public class RSA {
    
    private HashMap<String,KeyPair> agenda;
    
    public RSA() throws NoSuchAlgorithmException, NoSuchProviderException
    {
        agenda = new HashMap<String, KeyPair>();
        String nomes[] = new String[]{"Flavia","Willian","Leonardo","Fernando",
            "Alberto","Felipe","Renan","Bruno","Ramon","Valerio"};
        for(String nome: nomes)
            agenda.put(nome, this.generateKeys(nome));
    }

    public HashMap<String, KeyPair> getAgenda() {
        return agenda;
    }

    public void setAgenda(HashMap<String, KeyPair> agenda) {
        this.agenda = agenda;
    }
    
    public KeyPair generateKeys(String seed) throws NoSuchAlgorithmException, NoSuchProviderException
    {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        SecureRandom rng = SecureRandom.getInstance("SHA1PRNG", "SUN");
        rng.setSeed(seed.getBytes());
        keyGen.initialize(1024, rng);
        KeyPair key = keyGen.generateKeyPair();
        return key;
    }
    
    public byte[] Encriptar(String msg, Key k) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException
    {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, k);
        return cipher.doFinal(msg.getBytes());  
    }
    
    public byte[] Encriptar(byte[] msg, Key k) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException
    {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, k);
        return cipher.doFinal(msg);  
    }
    
    public byte[] Decifrar(String msg, Key k) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException
    {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, k);
        return cipher.doFinal(msg.getBytes());  
    }
    
    public byte[] Decifrar(byte[] msg, Key k) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException
    {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, k);
        return cipher.doFinal(msg);  
    }
}
