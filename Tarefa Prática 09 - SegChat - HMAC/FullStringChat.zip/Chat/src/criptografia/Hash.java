/*
 * Seguranca Computacional 2019.1 - Prof. Dr. Valerio Rosset
 * Pratica 09 
 * Nome: Flavia Yumi Ichikura RA: 111791
 * Nome: Willian Dihanster Gomes de Oliveira RA: 112269	
 */
package criptografia;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Arrays;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;

/**
 *
 * @author Flávia Yumi
 */
public class Hash {
    
    public byte[] gerarHash(String msg) throws NoSuchAlgorithmException, UnsupportedEncodingException
    {                    
        MessageDigest algorithm = MessageDigest.getInstance("SHA-1");//"SHA-256"
        byte messageDigest[] = algorithm.digest(msg.getBytes("UTF-8"));

        System.out.println("["+msg+"] hash gerado["+messageDigest.length+"]: "+new String(messageDigest));
        return messageDigest;
    }
    
    public byte[] gerarHash2(String msg, String user, Boolean privada) throws NoSuchAlgorithmException, UnsupportedEncodingException
    {                    
        Mac sha512_HMAC = null;
        sha512_HMAC = Mac.getInstance("HmacSHA512");      
        RSA rsa;
        byte [] mac_data = new byte[1];
        try {
            rsa = new RSA();
            KeyPair chaves = rsa.generateKeys(user);
            if(privada)
                sha512_HMAC.init(chaves.getPrivate());
            else
                sha512_HMAC.init(chaves.getPublic());
            mac_data = sha512_HMAC.doFinal(msg.getBytes("UTF-8"));
        } catch (NoSuchProviderException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        }
        return mac_data;
    }
    
    public byte[] montarMsg(String msg, String user)
    {
        try {
            byte[] codHash = this.gerarHash(msg);
            System.out.println("Hash antes do RSA "+codHash.length);
            RSA rsa = new RSA();
            codHash = rsa.Encriptar(codHash, rsa.getAgenda().get(user).getPrivate());
            
            String header = "MHeader|msgBytes:"+msg.getBytes().length+"|hashBytes:"+codHash.length+"|MHeader";
            ByteArrayOutputStream newMsg = new ByteArrayOutputStream( );
            newMsg.write(header.getBytes());
            newMsg.write(msg.getBytes());
            newMsg.write(codHash);
            byte c[] = newMsg.toByteArray( );

            System.out.println("Montou:\n"+new String(c,"windows-1252"));
            return c;
            
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchProviderException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalBlockSizeException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BadPaddingException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public boolean checkAuthenticity(byte[] msg, String user)
    {
        try {
            System.out.println("Check Autencity:[\n"+new String(msg,"windows-1252")+"]");
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            RSA rsa = new RSA();
            String msgS = new String(msg);
            String partes[] = msgS.split("MHeader");
            int hashSize = 0, msgSize=0;
            if(partes.length>1)
            {
                for(String a:partes[1].split("\\|"))
                {
                    if(a.length()>8)
                    {
                        if(a.substring(0,10).compareTo("hashBytes:")==0)
                        {
                            hashSize = Integer.parseInt(a.substring(10,a.length()));
                            System.out.println("HashSize: "+hashSize);
                        }
                        else if(a.substring(0,9).compareTo("msgBytes:")==0)
                        {
                            msgSize = Integer.parseInt(a.substring(9,a.length()));
                            System.out.println("msgSize: "+msgSize);
                        }
                    }
                }
            }
            String codHash = "";
            if(msg.length - hashSize > -1)
                codHash = new String(rsa.Decifrar(Arrays.copyOfRange(msg, msg.length - hashSize, msg.length), rsa.getAgenda().get(user).getPublic()),"windows-1252");
            String codHashNovo = "-";
            if(( msg.length - (hashSize+msgSize)>-1) && (msg.length - hashSize > 0) )
                codHashNovo= new String(this.gerarHash(new String(Arrays.copyOfRange(msg, msg.length - (hashSize+msgSize), msg.length - hashSize))),"windows-1252");
            System.out.println(/*(msg.length - hashSize)+" - "+msg.length+" */"Hash:"+codHash+"\n"+/* (msg.length - (hashSize+msgSize)) +" - "+ (msg.length - hashSize)+" */"HashNovo:"+codHashNovo);
            if(codHash.compareTo(codHashNovo)==0)
            {
                return true;
            }
            else
            {
                return false;
            }
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchProviderException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalBlockSizeException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BadPaddingException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public String getMessage(byte[] msg, String user)
    {        
        try {
            RSA rsa = new RSA();
            String msgS = new String(msg);
            String partes[] = msgS.split("MHeader");
            int hashSize = 0, msgSize=0;
            if(partes.length>1)
            {
                for(String a:partes[1].split("\\|"))
                {
                    if(a.length()>8)
                    {
                        if(a.substring(0,10).compareTo("hashBytes:")==0)
                        {
                            hashSize = Integer.parseInt(a.substring(10,a.length()));
                            System.out.println("HashSize: "+hashSize);
                        }
                        else if(a.substring(0,9).compareTo("msgBytes:")==0)
                        {
                            msgSize = Integer.parseInt(a.substring(9,a.length()));
                            System.out.println("msgSize: "+msgSize);
                        }
                    }
                }
            }
            String Mensagem = "";
            if(( msg.length - (hashSize+msgSize)>-1) && (msg.length - hashSize > 0) )
                Mensagem = new String(Arrays.copyOfRange(msg, msg.length - (hashSize+msgSize), msg.length - hashSize));
            return Mensagem;
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchProviderException ex) {
            Logger.getLogger(Hash.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }
    
    public static void main(String args[])
    {
        Hash h = new Hash();
        String plainText = "Ola, boa noiteFIMMSG\r\n";
        
        if(plainText.substring(plainText.length()-8, plainText.length()).compareTo("FIMMSG\r\n")==0)
            System.out.println("Sim");
        else
            System.out.println("Não");
        
        //byte[] newMsg = h.montarMsg(plainText, "Flavia");
        //System.out.println(h.checkAuthenticity(newMsg, "Flavia"));
        
    }
}
